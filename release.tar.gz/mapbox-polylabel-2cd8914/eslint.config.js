export {default} from 'eslint-config-mourner';
